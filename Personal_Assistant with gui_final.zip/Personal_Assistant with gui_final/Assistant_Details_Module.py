from Database_Module import get_assistant_name
name=get_assistant_name()
